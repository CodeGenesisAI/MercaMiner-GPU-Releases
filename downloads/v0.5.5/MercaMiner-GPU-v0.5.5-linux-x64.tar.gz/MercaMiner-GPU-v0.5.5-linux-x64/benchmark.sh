#!/bin/sh
# Measure hashrate for 60 seconds without a node. Add options to compare,
# e.g.  ./benchmark.sh --gpu-lanes 55
cd "$(dirname "$0")" || exit 1
exec ./mercaminer --benchmark "$@"
