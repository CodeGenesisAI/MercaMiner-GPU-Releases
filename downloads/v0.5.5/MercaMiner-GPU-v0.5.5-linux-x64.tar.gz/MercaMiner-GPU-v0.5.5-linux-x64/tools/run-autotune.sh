#!/bin/sh
# Find the best core (and memory) clock lock for each NVIDIA GPU.
# Stop the miner first. Needs root to change clocks:
#   sudo ./run-autotune.sh          every GPU, one after another
#   sudo ./run-autotune.sh 1        only GPU 1 (the miner's --list-devices /
#                                   --gpu-id number, not the dashboard #)
#   sudo ./run-autotune.sh 1 --min-core 1600 --max-core 2000 --step 50
# Each GPU takes about 5-10 minutes. Original clocks are restored after each
# GPU. Results are also saved to autotune-gpuN.txt.
cd "$(dirname "$0")" || exit 1
if [ "$(id -u)" != "0" ]; then
    echo "Run with sudo: changing GPU clocks needs root." >&2
    exit 1
fi
if [ $# -gt 0 ] && [ "${1#-}" = "$1" ]; then
    gpus=$1; shift
else
    count=$(nvidia-smi --query-gpu=index --format=csv,noheader 2>/dev/null | wc -l)
    [ "$count" -gt 0 ] || count=1
    gpus=$(seq 0 $((count - 1)))
fi
for gpu in $gpus; do
    echo "================ GPU $gpu ================"
    ./gpu-autotune "$gpu" --max-temp 71 "$@" 2>&1 | tee "autotune-gpu$gpu.txt"
done
echo
echo "Summary (best settings per GPU):"
for gpu in $gpus; do
    echo "--- GPU $gpu"
    grep -m1 -E '^Device|GPU [0-9]+:' "autotune-gpu$gpu.txt"
    grep -A1 -E '^(Fastest|Most efficient) error-free' "autotune-gpu$gpu.txt"
done
