#!/bin/sh
# ===================== EDIT THESE FOUR LINES =====================
# Your node's RPC address (testnet port 27775)
POOL="http://192.168.1.100:27775"
# Your wallet address (.name at the end = worker name)
WALLET="REPLACE_WITH_YOUR_tmca1_ADDRESS"
# Node RPC login: rpcuser:rpcpassword from the node's mercatura.conf
LOGIN="miner:YOUR_RPC_PASSWORD"
# Any other options (see README.txt)
OPTIONS="--gpu-max-temp 71 --api-enable --log-file miner.log"
# ==================================================================
# Extra options on the command line are added: ./start.sh --gpu-id 0,1
cd "$(dirname "$0")" || exit 1
# shellcheck disable=SC2086
exec ./mercaminer --algorithm mercahash --pool "$POOL" --wallet "$WALLET" \
    --password "$LOGIN" $OPTIONS "$@"
