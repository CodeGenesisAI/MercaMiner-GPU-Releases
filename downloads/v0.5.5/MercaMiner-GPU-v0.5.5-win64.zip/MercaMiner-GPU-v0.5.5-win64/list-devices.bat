@echo off
cd /d "%~dp0"
mercaminer-gpu.exe --list-devices
echo.
pause
