@echo off
rem Measure hashrate for 60 seconds without a node. Add options to compare,
rem e.g.  benchmark.bat --gpu-lanes 176
title MercaMiner GPU benchmark
cd /d "%~dp0"
mercaminer-gpu.exe --benchmark %*
echo.
pause
