@echo off
cd /d "%~dp0"
echo GPU stress test: kernel 3 vs kernel 4, every lane cross-checked. Close the miner first.
echo This takes about 1-2 minutes...
echo.
gpu-stress.exe 0 40 v3/g1/b32/c v4/g1/b32/c > stress-results.txt 2>&1
type stress-results.txt
echo.
echo Results saved to stress-results.txt
pause
