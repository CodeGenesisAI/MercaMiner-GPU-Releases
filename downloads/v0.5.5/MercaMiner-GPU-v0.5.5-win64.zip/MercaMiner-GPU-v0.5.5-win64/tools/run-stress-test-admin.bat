@echo off
net session >nul 2>&1
if %errorlevel% neq 0 (
  echo Requesting Administrator rights for GPU clock/power control...
  if "%~1"=="" (
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  ) else (
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -ArgumentList '%*' -Verb RunAs"
  )
  exit /b
)
cd /d "%~dp0"
echo GPU stress test with tuning: %*
echo Close the miner first. This takes about 1-2 minutes...
echo.
gpu-stress.exe 0 40 v3/g1/b32/c v4/g1/b32/c %* > stress-results.txt 2>&1
type stress-results.txt
echo.
echo Results saved to stress-results.txt
pause
