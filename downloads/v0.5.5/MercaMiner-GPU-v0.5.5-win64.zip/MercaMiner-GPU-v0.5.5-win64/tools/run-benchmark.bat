@echo off
cd /d "%~dp0"
if "%1"=="" (set G=0) else (set G=%1)
echo Benchmarking MercaHash kernels on GPU %G%. Close the miner first. This takes a few minutes...
echo.
gpu-bench.exe %G% 0 v4/g16/b16/c,v4/g16/b32/c,v4/g8/b32/c,v4/g4/b32/c,v4/g1/b32/c,v5/g16/b32/f4/c > benchmark-results.txt 2>&1
type benchmark-results.txt
echo.
echo Results saved to benchmark-results.txt
pause
