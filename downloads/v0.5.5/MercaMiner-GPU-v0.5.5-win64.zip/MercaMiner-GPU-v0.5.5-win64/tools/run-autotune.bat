@echo off
net session >nul 2>&1
if %errorlevel% neq 0 (
  echo Requesting Administrator rights for GPU clock control...
  if "%~1"=="" (
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  ) else (
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -ArgumentList '%*' -Verb RunAs"
  )
  exit /b
)
title MercaMiner GPU autotune
cd /d "%~dp0"
echo MercaMiner GPU autotune: tries core clock locks (and memory clocks if the driver allows),
echo measuring hashrate, power and errors for each. Close the miner first.
echo This takes about 5-10 minutes. Your original settings are restored at the end.
echo.
gpu-autotune.exe 0 %* > autotune-results.txt 2>&1
type autotune-results.txt
echo.
echo Results saved to autotune-results.txt
pause
