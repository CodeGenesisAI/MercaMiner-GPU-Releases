@echo off
rem Same as start-mining.bat, but runs as Administrator so NVIDIA clock,
rem power and fan options (--gpu-cclock, --gpu-plimit, --gpu-fan ...) work.
rem ===================== EDIT THESE FOUR LINES =====================
set POOL=http://127.0.0.1:27775
set WALLET=REPLACE_WITH_YOUR_tmca1_ADDRESS
rem (in a .bat file the password must not contain: ampersand, pipe, percent, caret, angle brackets)
set LOGIN=miner:YOUR_RPC_PASSWORD
set OPTIONS=--gpu-cclock 2000 --gpu-max-temp 71 --api-enable --log-file miner.log
rem ==================================================================

net session >nul 2>&1
if %errorlevel% neq 0 (
  echo Requesting Administrator rights for GPU clock/power control...
  powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)
title MercaMiner GPU (Administrator)
cd /d "%~dp0"
mercaminer-gpu.exe --algorithm mercahash --pool %POOL% --wallet %WALLET% --password %LOGIN% %OPTIONS%
echo.
echo Miner stopped. Press any key to close.
pause >nul
