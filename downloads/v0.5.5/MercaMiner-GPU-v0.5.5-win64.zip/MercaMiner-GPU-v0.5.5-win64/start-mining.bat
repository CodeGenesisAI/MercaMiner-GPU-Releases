@echo off
rem ===================== EDIT THESE FOUR LINES =====================
rem Your node's RPC address (testnet port 27775)
set POOL=http://127.0.0.1:27775
rem Your wallet address (.name at the end = worker name)
set WALLET=REPLACE_WITH_YOUR_tmca1_ADDRESS
rem Node RPC login: rpcuser:rpcpassword from the node's mercatura.conf
rem (in a .bat file the password must not contain: ampersand, pipe, percent, caret, angle brackets)
set LOGIN=miner:YOUR_RPC_PASSWORD
rem Any other options (see README.txt)
set OPTIONS=--gpu-max-temp 71 --api-enable --log-file miner.log
rem ==================================================================

title MercaMiner GPU
cd /d "%~dp0"
mercaminer-gpu.exe --algorithm mercahash --pool %POOL% --wallet %WALLET% --password %LOGIN% %OPTIONS% %*
echo.
echo Miner stopped. Press any key to close.
pause >nul
